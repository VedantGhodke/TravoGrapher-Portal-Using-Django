from django.apps import AppConfig


class UploadportalConfig(AppConfig):
    name = 'uploadportal'
